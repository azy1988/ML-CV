# 国庆假期选修作业参考答案

## 线性感知机算法（Perceptron Linear Algorithm）

### 阅读材料：

[台湾大学林轩田机器学习基石课程学习笔记2 -- Learning to Answer Yes/No](https://blog.csdn.net/red_stone1/article/details/70866527)
