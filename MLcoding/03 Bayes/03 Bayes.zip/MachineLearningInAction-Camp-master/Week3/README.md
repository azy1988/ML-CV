# 第三周

## 课程内容

- 《机器学习实战》第 5 章：Logistic 回归

- 《机器学习实战》第 6 章 6.1/6.2/6.3 节：支持向量机

## 包含文件

- Reference Code：参考代码

- Assignment：作业

- Materials：参考资料

## 参考资料

李航《统计学习方法》第 6 章 6.1 节

'./Materials/Logistic Regression/Logistic_Regression.ipynb'
